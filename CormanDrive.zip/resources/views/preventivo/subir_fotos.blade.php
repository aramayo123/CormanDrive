<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <style type="text/tailwindcss">
    @layer utilities {
      .content-auto {
        content-visibility: auto;
      }
    }
  </style>
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.css"  rel="stylesheet" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.js"></script>
</head>
<style>
    .loader {
        width: 20px;
        height: 20px;
        border: 5px solid #FFF;
        border-bottom-color: #FF3D00;
        border-radius: 50%;
        display: inline-block;
        box-sizing: border-box;
        animation: rotation 1s linear infinite;
    }

    @keyframes rotation {
        0% {
            transform: rotate(0deg);
        }
        100% {
            transform: rotate(360deg);
        }
    } 
</style>
<body>
    <div class="bg-gray-900 p-3 sm:p-5 antialiased" style="min-height: 688px;">
       <div class="mx-5 my-2">
        @if( $message )
            <div id="alert-3" class="max-w-xl text-center mx-auto flex items-center p-4 mb-4 text-green-400 rounded-lg bg-gray-800" role="alert">
                <svg class="flex-shrink-0 w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z"/>
                </svg>
                <span class="sr-only">Info</span>
                <div class="ml-3 text-xs font-medium">
                    <p>{{ $message }}</p>
                </div>
                <button type="button" class="ml-auto -mx-1.5 -my-1.5 rounded-lg focus:ring-2 focus:ring-green-400 p-1.5 inline-flex items-center justify-center h-8 w-8 bg-gray-800 text-green-400 hover:bg-gray-700" data-dismiss-target="#alert-3" aria-label="Close">
                <span class="sr-only">Close</span>
                <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                </svg>
                </button>
            </div>
        @endif
       </div>
       <div class="mx-5 my-6">
            <div class="max-w-xl mx-auto my-6 rounded-lg bg-gray-800 p-6" >
                <input type="hidden" name="sucursal" id="sucursal" value="{{ $sucursal }}" />
                <input type="hidden" name="mes" id="mes" value="{{ $mes }}" />
                
                <!-- EMPIEZA EL PROCESO !-->
                <label class="block mb-2 text-sm font-medium text-gray-400" for="fotos_preventivo">FOTOS DEL PREVENTIVO </label>   
                <div class="relative z-0 w-[110%] mb-5 group flex">
                    <div class="w-5/6">
                        <input type="file" name="fotos_preventivo" id="fotos_preventivo" class="block w-full text-sm border rounded-lg cursor-pointer text-white focus:outline-none bg-gray-700 border-gray-600 placeholder-gray-400">
                    </div>
                    <div> 
                        <span class="loader p-[7px] mx-[10px] mb-[5px] mt-[7px]" id="load-preventivo"></span>
                        <svg class="failed mt-1 ml-1 text-red-500" id="failed-preventivo" width="36" height="36" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">  <path stroke="none" d="M0 0h24v24H0z"/>  <line x1="18" y1="6" x2="6" y2="18" />  <line x1="6" y1="6" x2="18" y2="18" /></svg>
                        <svg class="success mt-1 ml-1 text-green-500" id="success-preventivo" width="36" height="36" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">  <path stroke="none" d="M0 0h24v24H0z"/>  <polyline points="9 11 12 14 20 6" />  <path d="M20 12v6a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2v-12a2 2 0 0 1 2 -2h9" /></svg>
                    </div>
                </div>
                <!-- TERMINA EL PROCESO !-->

                <!-- EMPIEZA EL PROCESO !-->
                <label class="block mb-2 text-sm font-medium text-gray-400" for="fotos_observaciones">FOTOS DE LAS OBSERVACIONES </label>   
                <div class="relative z-0 w-[110%] mb-5 group flex">
                    <div class="w-5/6">
                        <input type="file" name="fotos_observaciones" id="fotos_observaciones" class="block w-full text-sm border rounded-lg cursor-pointer text-white focus:outline-none bg-gray-700 border-gray-600 placeholder-gray-400">
                    </div>
                    <div> 
                        <span class="loader p-[7px] mx-[10px] mb-[5px] mt-[7px]" id="load-observaciones"></span>
                        <svg class="failed mt-1 ml-1 text-red-500" id="failed-observaciones" width="36" height="36" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">  <path stroke="none" d="M0 0h24v24H0z"/>  <line x1="18" y1="6" x2="6" y2="18" />  <line x1="6" y1="6" x2="18" y2="18" /></svg>
                        <svg class="success mt-1 ml-1 text-green-500" id="success-observaciones" width="36" height="36" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">  <path stroke="none" d="M0 0h24v24H0z"/>  <polyline points="9 11 12 14 20 6" />  <path d="M20 12v6a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2v-12a2 2 0 0 1 2 -2h9" /></svg>
                    </div>
                </div>
                <!-- TERMINA EL PROCESO !-->


                <!-- EMPIEZA EL PROCESO !-->
                <label class="block mb-2 text-sm font-medium text-gray-400" for="fotos_boleta">FOTOS DE BOLETAS </label>   
                <div class="relative z-0 w-[110%] mb-5 group flex">
                    <div class="w-5/6">
                        <input type="file" name="fotos_boleta" id="fotos_boleta" class="block w-full text-sm border rounded-lg cursor-pointer text-white focus:outline-none bg-gray-700 border-gray-600 placeholder-gray-400">
                    </div>
                    <div> 
                        <span class="loader p-[7px] mx-[10px] mb-[5px] mt-[7px]" id="load-boleta"></span>
                        <svg class="failed mt-1 ml-1 text-red-500" id="failed-boleta" width="36" height="36" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">  <path stroke="none" d="M0 0h24v24H0z"/>  <line x1="18" y1="6" x2="6" y2="18" />  <line x1="6" y1="6" x2="18" y2="18" /></svg>
                        <svg class="success mt-1 ml-1 text-green-500" id="success-boleta" width="36" height="36" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">  <path stroke="none" d="M0 0h24v24H0z"/>  <polyline points="9 11 12 14 20 6" />  <path d="M20 12v6a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2v-12a2 2 0 0 1 2 -2h9" /></svg>
                    </div>
                </div>
                <!-- TERMINA EL PROCESO !-->

                <div class="mx-auto text-center">
                    <button type="button" class="py-2.5 px-5 me-2 mb-2 text-sm font-medium focus:outline-none rounded-lg border focus:z-10 focus:ring-4 focus:ring-gray-100 focus:ring-gray-700 bg-gray-800 text-gray-400 border-gray-600 hover:text-white hover:bg-gray-700"><a href="{{ url('/') }}">GUARDAR</a></button>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const loaders = document.querySelectorAll('.loader');
        loaders.forEach(elemento => {
            elemento.style.display = 'none';
        })
        const success = document.querySelectorAll('.success');
        success.forEach(elemento => {
            elemento.style.display = 'none';
        })
        const faileds = document.querySelectorAll('.failed');
        faileds.forEach(elemento => {
            elemento.style.display = 'none';
        })
    });
    const rutaBase = "{{ env('APP_URL') }}";
    const sucursal = document.querySelector('#sucursal').value;
    const mes = document.querySelector('#mes').value;
    document.querySelector('#fotos_preventivo').addEventListener("change", (e) => {
        if(e.target.files.length) {
            const formData = new FormData();
            formData.append("fotos_preventivo", e.target.files[0]);
            enviarFoto(`${rutaBase}/preventivo/fotos_preventivo`, formData, 'preventivo');
        };
    });

    document.querySelector('#fotos_observaciones').addEventListener("change", (e) => {
        if(e.target.files.length) {
            const formData = new FormData();
            formData.append("fotos_observaciones", e.target.files[0]);
            enviarFoto(`${rutaBase}/preventivo/fotos_observaciones`, formData, 'observaciones');
        };
    });

    document.querySelector('#fotos_boleta').addEventListener("change", (e) => {
        if(e.target.files.length) {
            const formData = new FormData();
            formData.append("fotos_boleta", e.target.files[0]);
            enviarFoto(`${rutaBase}/preventivo/fotos_boleta`, formData, 'boleta');
        };
    });

    
    
    const showSpinner = (idElementHtml, isLoading) => {
        var elemento = document.querySelector("#" + idElementHtml);
        if(isLoading)
            elemento.style.display = 'block';
        else
            elemento.style.display = 'none';
    }

    const enviarFoto = async (url, formData, idElementHtml) => {
        showSpinner("load-"+idElementHtml, true);
        showSpinner("success-"+idElementHtml, false);
        showSpinner("failed-"+idElementHtml, false);
        try {
            formData.append("sucursal", sucursal);
            formData.append("mes", mes);
            const opciones = {
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                    'Accept': 'application/json',
                },
                method: 'POST',
                body: formData,
            };
            const res = await fetch(url, opciones);
            const data = await res.json();
            console.log(data.message)
            if(data.message === "Archivo no recibido."){
                showSpinner("load-"+idElementHtml, false);
                showSpinner("success-"+idElementHtml, false);
                showSpinner("failed-"+idElementHtml, true);
            }else{
                showSpinner("load-"+idElementHtml, false);
                showSpinner("success-"+idElementHtml, true);
                showSpinner("failed-"+idElementHtml, false);
            }
        } catch (error){
            showSpinner("load-"+idElementHtml, false);
            showSpinner("success-"+idElementHtml, false);
            showSpinner("failed-"+idElementHtml, true);
            console.log(error)
        }
        setTimeout(function () {
            showSpinner("load-"+idElementHtml, false);
            showSpinner("success-"+idElementHtml, false);
            showSpinner("failed-"+idElementHtml, false);
        }, 5000);
    }
</script>