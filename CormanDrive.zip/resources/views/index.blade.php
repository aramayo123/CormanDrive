@php
    use App\Models\Ot;
    use App\Models\Preventivo;
    $remedits = Ot::all();
    $preventivos = Preventivo::all();
    $arr_personal = ["DIEGO ARAMAYO","LUIS ARAMAYO","ALEJANDRO SAJAMA","CESAR ARAMAYO"];
@endphp

<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <style type="text/tailwindcss">
    @layer utilities {
      .content-auto {
        content-visibility: auto;
      }
    }
  </style>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.css"  rel="stylesheet" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.js"></script>
</head>
<body>
    <div class="bg-gray-900 p-3 sm:p-5 antialiased" style="min-height: 688px;"> 
        <div class="mx-auto text-center mt-2 mb-6">
            <h1 class="mb-4 text-center text-4xl font-extrabold leading-none tracking-tight text-gray-900 md:text-5xl lg:text-6xl dark:text-white">CORMAN FALICITIES S.R.L</h1>
            <p class="mb-6 text-lg font-normal text-gray-500 lg:text-xl sm:px-16 xl:px-48 dark:text-gray-400">En esta seccion se encuentra disponible todo lo relacionado a OTs.</p>
       </div>
       <div class="mx-5 my-2">
        @if( $message = Session::get('exito'))
            <div id="alert-3" class="flex items-center p-4 mb-4 text-green-400 rounded-lg bg-gray-800" role="alert">
                <svg class="flex-shrink-0 w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z"/>
                </svg>
                <span class="sr-only">Info</span>
                <div class="ml-3 text-sm font-medium">
                    <p>{{ $message }}</p>
                </div>
                <button type="button" class="ml-auto -mx-1.5 -my-1.5 rounded-lg focus:ring-2 focus:ring-green-400 p-1.5 inline-flex items-center justify-center h-8 w-8 bg-gray-800 text-green-400 hover:bg-gray-700" data-dismiss-target="#alert-3" aria-label="Close">
                <span class="sr-only">Close</span>
                <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                </svg>
                </button>
            </div>
        @endif
       </div>
       <div class="mx-5 my-2">
            <div class="flex items-center p-4 mb-4 rounded-lg bg-gray-800 text-green-400">
                <button type="button" class="py-2.5 px-5 me-2 mb-2 text-sm font-medium focus:outline-none rounded-lg border focus:z-10 focus:ring-4 focus:ring-gray-100 focus:ring-gray-700 bg-gray-800 text-gray-400 border-gray-600 hover:text-white hover:bg-gray-700"><a href="{{ url('/ot/crear') }}">AGREGAR</a></button>
                <button type="button" class="py-2.5 px-5 me-2 mb-2 text-sm font-medium focus:outline-none rounded-lg border focus:z-10 focus:ring-4 focus:ring-gray-100 focus:ring-gray-700 bg-gray-800 text-gray-400 border-gray-600 hover:text-white hover:bg-gray-700"><a href="" id="boton_editar_ot">EDITAR</a></button>
                <form action="" method="post" id="form_eliminar_ot">
                    @csrf
                    @method('delete')
                    <button type="button" id="boton-borrar-ot" class="py-2.5 px-5 me-2 mb-2 text-sm font-medium focus:outline-none rounded-lg border focus:z-10 focus:ring-4 focus:ring-gray-100 focus:ring-gray-700 bg-gray-800 text-gray-400 border-gray-600 hover:text-white hover:bg-gray-700">BORRAR</button>
                </form>
                <button type="button" class="py-2.5 px-5 me-2 mb-2 text-sm font-medium focus:outline-none rounded-lg border focus:z-10 focus:ring-4 focus:ring-gray-100 focus:ring-gray-700 bg-gray-800 text-gray-400 border-gray-600 hover:text-white hover:bg-gray-700">CERRAR</button>
            </div>
        </div>
       <div class="mx-5 my-2">
            <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
                <table class="w-full text-sm text-left rtl:text-right text-gray-400">
                    <thead class="text-xs uppercase bg-gray-700 text-gray-400">
                        <tr>
                            <th scope="col" class="p-4">
                                <div class="flex items-center">
                                    <input id="checkbox-all-search" disabled type="checkbox" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-600 ring-offset-gray-800 focus:ring-offset-gray-800 focus:ring-2 bg-gray-700 border-gray-600">
                                    <label for="checkbox-all-search" class="sr-only">checkbox</label>
                                </div>
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Remedit
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Sucursal
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Personal Asignado
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Fecha abierto
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Fecha cerrado
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Drive
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Estado
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($remedits as $remedit)
                        <tr class="bg-gray-800 border-gray-700 hover:bg-gray-600">
                            <td class="w-4 p-4">
                                <div class="flex items-center">
                                    <input id="checkbox-table-search-1" type="radio" name="remedit" onclick="EditarBorrarOt({{ $remedit->id }})" class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-600 ring-offset-gray-800 focus:ring-offset-gray-800 focus:ring-2 bg-gray-700 border-gray-600">
                                    <label for="checkbox-table-search-1" class="sr-only">checkbox</label>
                                </div>
                            </td>
                            <th scope="row" class="px-6 py-4 font-medium whitespace-nowrap text-white">
                                {{ $remedit->remedit }}
                            </th>
                            <td class="px-6 py-4">
                                {{ $remedit->sucursal }}
                            </td>
                            <td class="px-6 py-4">
                                <?php 
                                    $personal_remedit = str_split($remedit->personal_asignado);
                                    if($personal_remedit[0] == '1'){
                                        echo '<p><span class="bg-green-100 text-green-800 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-green-900 dark:text-green-300">'.$arr_personal[0].'</span></p>';
                                    }
                                    if($personal_remedit[2] == '1'){
                                        echo '<p><span class="bg-green-100 text-green-800 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-green-900 dark:text-green-300">'.$arr_personal[1].'</span></p>';
                                    }
                                    if($personal_remedit[4] == '1'){
                                        echo '<p><span class="bg-green-100 text-green-800 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-green-900 dark:text-green-300">'.$arr_personal[2].'</span></p>';
                                    }
                                    if($personal_remedit[6] == '1'){
                                        echo '<p><span class="bg-green-100 text-green-800 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-green-900 dark:text-green-300">'.$arr_personal[3].'</span></p>';
                                    }
                                    if($personal_remedit[0] == '0' && $personal_remedit[2] == '0' && $personal_remedit[4] == '0' && $personal_remedit[6] == '0'){
                                        echo '<p><span class="bg-green-100 text-green-800 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-green-900 dark:text-green-300">SIN PERSONAL ASIGNADO</span></p>';
                                    }
                                ?>
                            </td>
                            <td class="px-6 py-4">
                                {{ $remedit->fecha_abierto }}
                            </td>
                            <td class="px-6 py-4">
                                {{ $remedit->fecha_cerrado }}
                            </td>
                            <td class="px-6 py-4">
                                <button type="button" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-xs px-3 py-2.5 me-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800"><a href="{{ $remedit->url_carpeta }}" target="_blank" >CARPETA DRIVE</a></button>
                            </td>
                            <td class="px-6 py-4">
                                {{ $remedit->estado }}
                            </td>
                        </tr>
                        @empty
                            <tr>
                                <td class="px-4 py-3">No hay remedits creados</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
       </div>

       <div class="mx-auto text-center mt-[100px] mb-6">
            <p class="mb-6 text-lg font-normal text-gray-500 lg:text-xl sm:px-16 xl:px-48 dark:text-gray-400">En esta seccion se encuentra disponible todo lo relacionado a PREVENTIVOS.</p>
        </div>
        
       <div class="mx-5 my-2">
            <div class="flex items-center p-4 mb-4 rounded-lg bg-gray-800 text-green-400">
                <button type="button" class="py-2.5 px-5 me-2 mb-2 text-sm font-medium focus:outline-none rounded-lg border focus:z-10 focus:ring-4 focus:ring-gray-100 focus:ring-gray-700 bg-gray-800 text-gray-400 border-gray-600 hover:text-white hover:bg-gray-700"><a href="{{ url('/preventivo/crear') }}">AGREGAR</a></button>
                <button type="button" class="py-2.5 px-5 me-2 mb-2 text-sm font-medium focus:outline-none rounded-lg border focus:z-10 focus:ring-4 focus:ring-gray-100 focus:ring-gray-700 bg-gray-800 text-gray-400 border-gray-600 hover:text-white hover:bg-gray-700"><a href="" id="boton_editar_preventivo">EDITAR</a></button>
                <form action="" method="post" id="form_eliminar_preventivo">
                    @csrf
                    @method('delete')
                    <button type="button" id="boton-borrar-preventivo" class="py-2.5 px-5 me-2 mb-2 text-sm font-medium focus:outline-none rounded-lg border focus:z-10 focus:ring-4 focus:ring-gray-100 focus:ring-gray-700 bg-gray-800 text-gray-400 border-gray-600 hover:text-white hover:bg-gray-700">BORRAR</button>
                </form>
                <button type="button" class="py-2.5 px-5 me-2 mb-2 text-sm font-medium focus:outline-none rounded-lg border focus:z-10 focus:ring-4 focus:ring-gray-100 focus:ring-gray-700 bg-gray-800 text-gray-400 border-gray-600 hover:text-white hover:bg-gray-700">CERRAR</button>
            </div>
        </div>
        <div class="mx-5 my-2">
            <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
                <table class="w-full text-sm text-left rtl:text-right text-gray-400">
                    <thead class="text-xs uppercase bg-gray-700 text-gray-400">
                        <tr>
                            <th scope="col" class="p-4">
                                <div class="flex items-center">
                                    <input id="checkbox-all-search" disabled type="checkbox" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-600 ring-offset-gray-800 focus:ring-offset-gray-800 focus:ring-2 bg-gray-700 border-gray-600">
                                    <label for="checkbox-all-search" class="sr-only">checkbox</label>
                                </div>
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Cliente
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Sucursal
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Personal asignado
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Fecha
                            </th>
                            <th scope="col" class="px-6 py-3">
                               Observaciones
                            </th>
                            <th scope="col" class="px-6 py-3">
                               Folder
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($preventivos as $preventivo)
                        <tr class="bg-gray-800 border-gray-700 hover:bg-gray-600">
                            <td class="w-4 p-4">
                                <div class="flex items-center">
                                    <input id="checkbox-table-search-1" type="radio" name="preventivo" onclick="EditarBorrarPreventivo({{ $preventivo->id }})" class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-600 ring-offset-gray-800 focus:ring-offset-gray-800 focus:ring-2 bg-gray-700 border-gray-600">
                                    <label for="checkbox-table-search-1" class="sr-only">checkbox</label>
                                </div>
                            </td>
                            <th scope="row" class="px-6 py-4 font-medium whitespace-nowrap text-white">
                                {{ $preventivo->cliente }}
                            </th>
                            <td class="px-6 py-4">
                                {{ $preventivo->sucursal }}
                            </td>
                            <td class="px-6 py-4">
                                <?php 
                                    $personal_preventivo = str_split($preventivo->personal_asignado);
                                    if($personal_preventivo[0] == '1'){
                                        echo '<p><span class="bg-green-100 text-green-800 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-green-900 dark:text-green-300">'.$arr_personal[0].'</span></p>';
                                    }
                                    if($personal_preventivo[2] == '1'){
                                        echo '<p><span class="bg-green-100 text-green-800 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-green-900 dark:text-green-300">'.$arr_personal[1].'</span></p>';
                                    }
                                    if($personal_preventivo[4] == '1'){
                                        echo '<p><span class="bg-green-100 text-green-800 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-green-900 dark:text-green-300">'.$arr_personal[2].'</span></p>';
                                    }
                                    if($personal_preventivo[6] == '1'){
                                        echo '<p><span class="bg-green-100 text-green-800 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-green-900 dark:text-green-300">'.$arr_personal[3].'</span></p>';
                                    }
                                    if($personal_preventivo[0] == '0' && $personal_preventivo[2] == '0' && $personal_preventivo[4] == '0' && $personal_preventivo[6] == '0'){
                                        echo '<p><span class="bg-green-100 text-green-800 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-green-900 dark:text-green-300">SIN PERSONAL ASIGNADO</span></p>';
                                    }
                                ?>
                            </td>
                            <td class="px-6 py-4">
                                {{ $preventivo->fecha }}
                            </td>
                            <td class="px-6 py-4">
                                {{ $preventivo->observaciones }}
                            </td>
                            <td class="px-6 py-4">
                                <button type="button" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-xs px-3 py-2.5 me-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800"><a href="{{ $preventivo->url_carpeta }}" target="_blank" >CARPETA DRIVE</a></button>
                            </td>
                        </tr>
                        @empty
                            <tr>
                                <td class="px-4 py-3">No hay preventivos creados</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>


    </div>
</body>
</html>

<script>
    function EditarBorrarOt(id){
        var boton_editar = document.querySelector("#boton_editar_ot");
        var url = window.location + 'ot/editar/'+id;
        boton_editar.setAttribute('href', url)

        var form_borrar = document.querySelector("#form_eliminar_ot");
        var url = window.location + 'ot/borrar/'+id;
        form_borrar.setAttribute('action', url)
        var boton_borrar = document.querySelector("#boton-borrar-ot");
        boton_borrar.setAttribute('type', 'submit');
    }
    function EditarBorrarPreventivo(id){
        var boton_editar = document.querySelector("#boton_editar_preventivo");
        var url = window.location + 'preventivo/editar/'+id;
        boton_editar.setAttribute('href', url)

        var form_borrar = document.querySelector("#form_eliminar_preventivo");
        var url = window.location + 'preventivo/borrar/'+id;
        form_borrar.setAttribute('action', url)
        var boton_borrar = document.querySelector("#boton-borrar-preventivo");
        boton_borrar.setAttribute('type', 'submit');
    }
</script>