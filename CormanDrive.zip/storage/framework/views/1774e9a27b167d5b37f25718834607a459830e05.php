<form action="<?php echo e(url('/caca')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="file" name="archivos[]" multiple>
    <input type="submit" value="Enviar">
</form><?php /**PATH E:\wamp64\www\CormanDrive\resources\views/caca.blade.php ENDPATH**/ ?>